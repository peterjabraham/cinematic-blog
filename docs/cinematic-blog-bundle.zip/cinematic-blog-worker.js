/**
 * Cinematic Blog Brief API
 * Cloudflare Worker for storing and retrieving blog post briefs
 * 
 * Setup:
 * 1. Create KV namespace "BLOG_BRIEFS" in Cloudflare dashboard
 * 2. Bind it to this worker as "BRIEFS"
 * 3. Deploy this worker
 */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    // CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    // Handle preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    try {
      // Route handling
      if (path === '/submit' && request.method === 'POST') {
        return await handleSubmit(request, env, corsHeaders);
      }
      
      if (path === '/briefs' && request.method === 'GET') {
        return await handleList(request, env, corsHeaders);
      }
      
      if (path.startsWith('/briefs/') && request.method === 'GET') {
        const id = path.replace('/briefs/', '');
        return await handleGet(id, env, corsHeaders);
      }
      
      if (path.startsWith('/briefs/') && request.method === 'DELETE') {
        const id = path.replace('/briefs/', '');
        return await handleDelete(id, env, corsHeaders);
      }

      if (path === '/export' && request.method === 'GET') {
        return await handleExport(env, corsHeaders);
      }

      // Health check
      if (path === '/health') {
        return new Response(JSON.stringify({ status: 'ok', timestamp: new Date().toISOString() }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      return new Response(JSON.stringify({ error: 'Not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });

    } catch (err) {
      return new Response(JSON.stringify({ error: err.message }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }
  }
};

/**
 * Handle brief submission
 */
async function handleSubmit(request, env, corsHeaders) {
  const body = await request.json();
  
  // Validate required fields
  if (!body.topic || !body.audience) {
    return new Response(JSON.stringify({ error: 'Topic and audience are required' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  // Generate unique ID
  const id = generateId();
  const timestamp = new Date().toISOString();

  // Prepare record
  const record = {
    id,
    topic: body.topic,
    audience: body.audience,
    pov: body.pov || null,
    title: body.title || null,
    tone: body.tone || null,
    sources: body.sources || null,
    scenes: body.scenes || null,
    length: body.length || 'Medium (1,500–2,000 words)',
    avoid: body.avoid || null,
    brief: body.brief || null,
    createdAt: timestamp,
    status: 'pending' // pending, drafted, published
  };

  // Store in KV
  await env.BRIEFS.put(`brief:${id}`, JSON.stringify(record));
  
  // Update index
  await updateIndex(env, id, timestamp);

  return new Response(JSON.stringify({ 
    success: true, 
    id,
    message: 'Brief saved successfully'
  }), {
    status: 201,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
}

/**
 * List all briefs
 */
async function handleList(request, env, corsHeaders) {
  const url = new URL(request.url);
  const limit = parseInt(url.searchParams.get('limit') || '50');
  const status = url.searchParams.get('status'); // filter by status

  // Get index
  const indexData = await env.BRIEFS.get('index:briefs');
  const index = indexData ? JSON.parse(indexData) : [];

  // Get briefs (most recent first)
  const briefs = [];
  for (const entry of index.slice(0, limit)) {
    const data = await env.BRIEFS.get(`brief:${entry.id}`);
    if (data) {
      const brief = JSON.parse(data);
      if (!status || brief.status === status) {
        briefs.push({
          id: brief.id,
          topic: brief.topic,
          title: brief.title,
          audience: brief.audience,
          tone: brief.tone,
          length: brief.length,
          status: brief.status,
          createdAt: brief.createdAt
        });
      }
    }
  }

  return new Response(JSON.stringify({ briefs, count: briefs.length }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
}

/**
 * Get single brief by ID
 */
async function handleGet(id, env, corsHeaders) {
  const data = await env.BRIEFS.get(`brief:${id}`);
  
  if (!data) {
    return new Response(JSON.stringify({ error: 'Brief not found' }), {
      status: 404,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  return new Response(data, {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
}

/**
 * Delete brief by ID
 */
async function handleDelete(id, env, corsHeaders) {
  await env.BRIEFS.delete(`brief:${id}`);
  await removeFromIndex(env, id);

  return new Response(JSON.stringify({ success: true, message: 'Brief deleted' }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
}

/**
 * Export all briefs as JSON
 */
async function handleExport(env, corsHeaders) {
  const indexData = await env.BRIEFS.get('index:briefs');
  const index = indexData ? JSON.parse(indexData) : [];

  const briefs = [];
  for (const entry of index) {
    const data = await env.BRIEFS.get(`brief:${entry.id}`);
    if (data) {
      briefs.push(JSON.parse(data));
    }
  }

  return new Response(JSON.stringify({ briefs, exportedAt: new Date().toISOString() }), {
    headers: { 
      ...corsHeaders, 
      'Content-Type': 'application/json',
      'Content-Disposition': 'attachment; filename="blog-briefs-export.json"'
    }
  });
}

/**
 * Generate unique ID
 */
function generateId() {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return `${timestamp}-${random}`;
}

/**
 * Update index with new brief
 */
async function updateIndex(env, id, timestamp) {
  const indexData = await env.BRIEFS.get('index:briefs');
  const index = indexData ? JSON.parse(indexData) : [];
  
  // Add to beginning (most recent first)
  index.unshift({ id, createdAt: timestamp });
  
  // Keep only last 1000
  if (index.length > 1000) {
    index.length = 1000;
  }

  await env.BRIEFS.put('index:briefs', JSON.stringify(index));
}

/**
 * Remove brief from index
 */
async function removeFromIndex(env, id) {
  const indexData = await env.BRIEFS.get('index:briefs');
  if (!indexData) return;

  const index = JSON.parse(indexData);
  const filtered = index.filter(entry => entry.id !== id);
  await env.BRIEFS.put('index:briefs', JSON.stringify(filtered));
}
